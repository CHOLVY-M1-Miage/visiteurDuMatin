package edu.uga.miage.m1.polygons.gui;

/**
 * Hello world!
 * 
 * @author <a href="mailto:christophe.saint-marcel@univ-grenoble-alpes.fr">Christophe</a>
 *
 */
public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {
		GUIHelper.showOnFrame("Visiteur du matin CHOLVY Jordan IERMOLLI Quentin");
	}
}
