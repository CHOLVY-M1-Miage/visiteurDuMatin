package edu.uga.miage.m1.polygons.gui.persistence;

import edu.uga.miage.m1.polygons.gui.shapes.*;

import java.util.List;

/**
 * @author <a href="mailto:christophe.saint-marcel@univ-grenoble-alpes.fr">Christophe</a>
 */
public class JSonVisitor implements Visitor {

    private String representation = "";

    public JSonVisitor() {
    }

    @Override
    public void visit(Circle circle) {
    this.representation = String.format("{\"type\": \"%s\", \"x\": %d,\"y\": %d}", "circle", circle.getX(), circle.getY());

    }

    @Override
    public void visit(Square square) {
        this.representation = String.format("{\"type\": \"%s\", \"x\": %d,\"y\": %d}", "square", square.getX(), square.getY());
    }

    @Override
    public void visit(Triangle triangle) {
        this.representation = String.format("{\"type\": \"%s\", \"x\": %d,\"y\": %d}", "triangle", triangle.getX(), triangle.getY());
    }

    @Override
    public void visit(GroupeShape shapes) {
        JSonVisitor visitor = new JSonVisitor();
        List<SimpleShape> listeShapes = shapes.getShapes();
        SimpleShape lastShape = listeShapes.get(listeShapes.size() - 1);
        for (SimpleShape s: shapes.getShapes()){
            s.accept(visitor);
            this.representation += visitor.getRepresentation();
            if (!s.equals(lastShape)){
                this.representation += ",\n";
            }
        }
    }

    /**
     * @return the representation in JSon example for a Circle
     *
     *         <pre>
     * {@code
     *  {
     *     "shape": {
     *     	  "type": "circle",
     *        "x": -25,
     *        "y": -25
     *     }
     *  }
     * }
     *         </pre>
     */
    public String getRepresentation() {
        return representation;
    }
}
