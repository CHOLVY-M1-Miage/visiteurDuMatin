package edu.uga.miage.m1.polygons.gui.persistence;

import edu.uga.miage.m1.polygons.gui.shapes.*;

import java.util.List;

/**
 * @author <a href="mailto:christophe.saint-marcel@univ-grenoble-alpes.fr">Christophe</a>
 */
public class XMLVisitor implements Visitor {

    private String representation = "";

    public XMLVisitor() {
    }

    @Override
    public void visit(Circle circle) {
        this.representation = String.format("<shape><type>%s</type><x>%d</x><y>%d</y></shape>", "circle", circle.getX(), circle.getY());
    }

    @Override
    public void visit(Square square) {
        this.representation = String.format("<shape><type>%s</type><x>%d</x><y>%d</y></shape>", "square", square.getX(), square.getY());
    }

    @Override
    public void visit(Triangle triangle) {
        this.representation = String.format("<shape><type>%s</type><x>%d</x><y>%d</y></shape>", "triangle", triangle.getX(), triangle.getY());
    }

    @Override
    public void visit(GroupeShape shapes) {
        XMLVisitor visitor =new XMLVisitor();
        List<SimpleShape> listeShapes = shapes.getShapes();
        SimpleShape lastShape = listeShapes.get(listeShapes.size() - 1);
        for (SimpleShape s: shapes.getShapes()){
            s.accept(visitor);
            this.representation += visitor.getRepresentation();
            if (!s.equals(lastShape)){
                this.representation += "\n";
            }
        }
    }

    /**
     * @return the representation in JSon example for a Triangle:
     *
     *         <pre>
     * {@code
     *  <shape>
     *    <type>triangle</type>
     *    <x>-25</x>
     *    <y>-25</y>
     *  </shape>
     * }
     * </pre>
     */
    public String getRepresentation() {
        return representation;
    }
}
